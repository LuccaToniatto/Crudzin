﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Coisa
{
    class Dados
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public string celular { get; set; }
        public string email { get; set; }
        public DateTime data_nas { get; set; }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\programa\Coisa\Coisa\DbBanco.mdf;Integrated Security=True");
        public List<Dados> listadados()
        {
            List<Dados> da = new List<Dados>();
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Dados";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Dados dad = new Dados();
                dad.Id = (int)dr["Id"];
                dad.nome = dr["nome"].ToString();
                dad.celular = dr["celular"].ToString();
                dad.email = dr["email"].ToString();
                dad.data_nas = Convert.ToDateTime(dr["data_nas"]);
                da.Add(dad);
            }
            return da;
        }
         // string sql = "string exec"
         //con.open
         //cmd = new sql command sql,con
         //cmd.executenonquery
         //con.close
         //👌
        public void cadastrar(string nome, string celular, string email, DateTime data_nas)
        {
            con.Open();
            string dta = data_nas.ToString("yyyy/MM/dd");
            string sql = "INSERT INTO Dados (nome,celular,email,data_nas) VALUES ('" + nome + "','" + celular + "','" + email + "','" + dta + "')";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        public void localizar(int Id)
        {
            con.Open();
            string sql = "SELECT * FROM Dados WHERE Id = '" + Id + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Id = (int)dr["Id"];
                nome = dr["nome"].ToString();
                celular = dr["celular"].ToString();
                email = dr["email"].ToString();
                data_nas = Convert.ToDateTime(dr["data_nas"]);
            }
            con.Close();
        }

        public void atualizar(int Id, string nome, string celular, string email, DateTime data_nas)
        {
            con.Open();
            string dta = data_nas.ToString("yyyy/MM/dd");
            string sql = "UPDATE Dados SET nome='" + nome + "', celular='" + celular + "',email='" + email + "',data_nas='" + dta + "' where Id = '"+Id+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void excluir(int Id)
        {
            con.Open();
            string sql = "DELETE FROM Dados WHERE Id='"+Id+"'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}
