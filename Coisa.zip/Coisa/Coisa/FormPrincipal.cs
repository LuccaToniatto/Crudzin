﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Coisa
{
    public partial class FormPrincipal : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\programa\Coisa\Coisa\DbBanco.mdf;Integrated Security=True");
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            con.Open();
            Dados dados = new Dados();
            dados.cadastrar(txtNome.Text, txtCelular.Text, txtEmail.Text, dtpDataNas.Value);
            List<Dados> dados1 = dados.listadados();
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            Dados da = new Dados();
            List<Dados> daddos = da.listadados();
            dgvCrud.DataSource = daddos;
            con.Close();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            Dados da = new Dados();
            List<Dados> dados = da.listadados();
            dgvCrud.DataSource = dados;
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            con.Open();
            Dados dados = new Dados();
            int idd = Convert.ToInt32(txtId.Text.Trim());
            dados.localizar(idd);
            txtNome.Text = dados.nome;
            txtCelular.Text = dados.celular;
            txtEmail.Text = dados.email;
            con.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            con.Open();
            Dados dados = new Dados();
            int idd = Convert.ToInt32(txtId.Text.Trim());
            dados.atualizar(idd,txtNome.Text, txtCelular.Text, txtEmail.Text, dtpDataNas.Value);
            txtNome.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
            Dados da = new Dados();
            List<Dados> daddos = da.listadados();
            dgvCrud.DataSource = daddos;
            con.Close();

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            con.Open();
            Dados dados = new Dados();
            int idd = Convert.ToInt32(txtId.Text.Trim());
            dados.excluir(idd);
            Dados da = new Dados();
            List<Dados> daddos = da.listadados();
            dgvCrud.DataSource = daddos;
            con.Close();
        }

        private void btnFormFoda_Click(object sender, EventArgs e)
        {
            FormFoda fo = new FormFoda();
            fo.Show();
        }
    }
}
